from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
import bcrypt

def index(request):
    return render(request, "login/index.html")



def register(request):
    errors = User.objects.validator(request.POST, "registration")
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        
        hasPassword = bcrypt.hashpw(request.POST['reg-pword'].encode(), bcrypt.gensalt()).decode() 
        User.objects.create(first_name=request.POST['reg-fname'], last_name=request.POST['reg-lname'], email=request.POST['reg-email'], password=hasPassword)
        thisUser = User.objects.last()
        request.session['user_id'] = thisUser.id
        request.session['user_fname'] = thisUser.first_name
        return redirect("/wall")


def login(request):
    user = User.objects.filter(email=request.POST['log-email'])
    if user:
        logged_user = user[0] 
        if bcrypt.checkpw(request.POST['log-pword'].encode(), logged_user.password.encode()):
            request.session['user_id'] = logged_user.id
            request.session['user_fname'] = logged_user.first_name
            return redirect("/wall")
        else:
            messages.error(request, "The email and password combination entered do not match a record in our database")
            return redirect('/')  
    messages.error(request, "The email and password combination entered do not match a record in our database")   
    return redirect ('/')
    

def wall(request):
    if 'user_id' not in request.session:
        return redirect("/")
    else:
        return render(request, "login/wall.html")

def logout(request):
    request.session.clear()
    return redirect("/")